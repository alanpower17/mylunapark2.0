# 🎡 MyLunaPark — Web App

Applicazione web SPA (Single Page Application) per la gestione di coupon nei luna park italiani.  
Basata su **Vanilla JS + Firebase + Tailwind CSS** (versione browser-only, senza build step).

---

## ✅ Funzionalità Implementate

### 🏠 Home
- Lista di tutti i luna park (da Firestore o fallback demo)
- Ricerca per nome / città con debounce
- Filtro per regione (Nord / Centro / Sud & Isole)
- Geolocalizzazione: ordina i parchi per distanza dall'utente
- Preferiti: cuore ❤️ su ogni card per salvare/rimuovere

### 🔐 Login / Registrazione
- Login con email e password (Firebase Auth)
- Registrazione con scelta del ruolo:
  - 👤 Utente
  - 🏟️ Organizzatore Luna Park
  - 🎠 Gestore Giostra
- Messaggi di errore localizzati in italiano

### 🎡 Dettaglio Parco
- Immagine, nome, città, distanza, telefono, sito web
- Lista coupon del parco con badge sconto
- Sistema cooldown (timer 24h per ogni coupon)
- Modale di conferma riscatto
- Tracciamento utilizzo su Firestore (`couponUses`)

### ❤️ Preferiti
- Lista parchi preferiti dell'utente
- Sincronizzata con Firestore (`users/{uid}.favorites`)

### 👤 Profilo
- Avatar con iniziali, nome, email, ruolo
- Statistiche rapide (n° preferiti, data iscrizione)
- Scorciatoie per dashboard ruolo (Organizzatore / Admin)
- Logout

### 👑 Pannello Admin (`/admin`)
- Creazione sponsor (immagine, link click, target coupon/park)
- Lista e rimozione sponsor attivi
- Gestione ruoli utenti
- Link alle statistiche sponsor

### 📊 Statistiche Sponsor (`/admin-stats`)
- KPI globali: Views, Click, CTR%
- Dettaglio per sponsor con barra CTR
- Calcolo CTR = clicks / views × 100

### 🏟️ Dashboard Organizzatore (`/organizer`)
- Tab: I miei Parchi / Gestione Coupon / Crea Nuovo Parco
- Creazione parco con tutti i campi (lat/lon, immagine, sito, ecc.)
- Aggiunta e rimozione coupon per parco
- Visualizzazione lista coupon esistenti

---

## 📁 Struttura File

```
/
├── index.html                  # HTML principale con navbar e skeleton SPA
├── css/
│   └── style.css               # Stili personalizzati (dark theme gold/neon)
└── js/
    ├── firebase-config.js      # Inizializzazione Firebase
    ├── auth.js                 # Auth service (login, register, logout, preferiti, ruoli)
    ├── parks.js                # Parks service (fetch, distanza, filtri, dati demo)
    ├── coupons.js              # Coupons service (fetch, usa, cooldown, sync sheets)
    ├── sponsors.js             # Sponsors service (fetch, crea, tracking, stats)
    ├── utils.js                # Utilities (toast, loading, modal, debounce, formatDate)
    └── app.js                  # Router SPA + tutte le pagine renderizzate
```

---

## 🔗 URI / Pagine (routing client-side)

| Pagina | Chiamata JS | Descrizione |
|--------|------------|-------------|
| `/` | `navigateTo('home')` | Home con lista parchi |
| `/search` | `navigateTo('search')` | Pagina ricerca |
| `/login` | `navigateTo('login')` | Login/Registrazione |
| `/park/:id` | `navigateTo('park', {id})` | Dettaglio parco + coupon |
| `/favorites` | `navigateTo('favorites')` | Parchi preferiti |
| `/profile` | `navigateTo('profile')` | Profilo utente |
| `/admin` | `navigateTo('admin')` | Pannello admin |
| `/admin-stats` | `navigateTo('admin-stats')` | Statistiche sponsor |
| `/organizer` | `navigateTo('organizer')` | Dashboard organizzatore |

---

## 🔥 Configurazione Firebase

**Progetto:** `mylunaparkchatgpt`

```js
const firebaseConfig = {
  apiKey: "AIzaSyBRVXc2rCK9zIgIKMitnkdQfqxZXYMcI0w",
  authDomain: "mylunaparkchatgpt.firebaseapp.com",
  projectId: "mylunaparkchatgpt",
  storageBucket: "mylunaparkchatgpt.firebasestorage.app",
  messagingSenderId: "915512401969",
  appId: "1:915512401969:web:919e77a70ba3a9259e3510"
};
```

### ⚠️ Attivazione richiesta nel Firebase Console:
1. **Authentication** → Email/Password: ABILITARE
2. **Firestore Database**: CREARE e impostare regole
3. **Regole Firestore** consigliate per test:
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if request.auth != null;
    }
    match /LunaParks/{doc} {
      allow read: if true;
    }
    match /coupons/{doc} {
      allow read: if true;
    }
  }
}
```

---

## 🗄️ Struttura Dati Firestore (Collezioni)

| Collezione | Descrizione |
|-----------|-------------|
| `users` | Profili utente (uid, name, email, role, favorites[]) |
| `LunaParks` | Parchi (nome, citta, regione, lat, lon, image, status, organizerIds[]) |
| `coupons` | Coupon (parkId, nomeAttrazione, valoreSconto, cooldownHours, image...) |
| `couponUses` | Log utilizzi (userId, couponId, parkId, usedAt) |
| `sponsorImages` | Sponsor (imageURL, clickURL, couponId, parkId, name) |
| `sponsorStats` | Tracking (sponsorId, type: view/click, timestamp) |

---

## 🚀 Modalità Demo (senza Firebase)

Se Firestore non è disponibile, l'app carica automaticamente **6 parchi demo italiani**:
- Gardaland, Mirabilandia, Movieland Park, Etnaland, LEGOLAND, Rainbow Magicland

Ogni parco demo ha 4 coupon di esempio. I preferiti in modalità demo sono gestiti localmente.

---

## 🛠️ Da Implementare (Next Steps)

- [ ] QR Code scanner per riscatto fisico coupon
- [ ] Dashboard Gestore Giostra (visualizzazione coupon proprie attrazioni)
- [ ] Sync coupon da Google Sheets (UI per URL del foglio)
- [ ] Push notifications per nuovi coupon
- [ ] Sistema rating/recensioni parchi
- [ ] Mappa interattiva con i parchi (Google Maps / Leaflet)
- [ ] Filtro per data di validità coupon
- [ ] Registrazione PWA (installabile su mobile)
- [ ] Export statistiche CSV

---

## 🎨 Design System

| Colore | Hex | Utilizzo |
|--------|-----|---------|
| `primary` | `#020617` | Sfondo principale |
| `amber` | `#FFBF00` | Colore primario / titoli |
| `neon` | `#00FFFF` | Accenti / distanza / neon |
| `card` | `#0f172a` | Sfondo card |

---

*MyLunaPark — Coupon esclusivi nei migliori luna park italiani 🎡*
